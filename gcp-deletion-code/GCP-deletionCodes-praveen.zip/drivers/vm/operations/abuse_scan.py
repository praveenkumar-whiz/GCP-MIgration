import json
import logging
from typing import Any, Dict

from execution_plane.platform.gcp.sdk.client import GCPAPIError, GCPClientFactory

# -------------------------------------------------------------------
# Logger configuration
# -------------------------------------------------------------------
logger = logging.getLogger("gcp-vm-abuse")
logger.setLevel(logging.INFO)


def abuse_scan_spec(spec: Dict[str, Any]) -> Dict[str, Any]:
    """
    Real GCP VM abuse scan.

    Expected spec keys:
    - project_id
    - gcp_access_token / access_token
    - zone (optional)
    - rules: { "instance": { ... rule json ... } }
    """
    masked_spec = dict(spec)
    for key in ("gcp_access_token", "access_token", "google_access_token"):
        if masked_spec.get(key):
            masked_spec[key] = "***REDACTED***"

    logger.info("GCP VM Abuse Scan triggered")
    logger.info("Incoming spec: %s", json.dumps(masked_spec))

    # -------------------------------------------------------------------
    # Validate target scope and abuse rules
    # -------------------------------------------------------------------
    rules = spec.get("rules", {}) or {}
    instance_rules = rules.get("instance", {}) if isinstance(rules, dict) else {}
    logger.info("Abuse rules: %s", json.dumps(rules))

    zone = spec.get("zone")
    region = spec.get("region") or zone
    if not zone and not region:
        return {
            "status": "FAILED",
            "action": "VM_ABUSE_SCAN",
            "reason": "ZoneOrRegionRequired",
        }

    try:
        # -------------------------------------------------------------------
        # Build project context and authenticated compute client
        # -------------------------------------------------------------------
        project_id = str(spec.get("project_id") or spec.get("gcp_project_id") or "").strip()
        if not project_id:
            raise ValueError("project_id is required for GCP VM operations")

        compute_client = GCPClientFactory.create(
            "compute",
            creds={
                "access_token": (
                    spec.get("gcp_access_token")
                    or spec.get("access_token")
                    or spec.get("google_access_token")
                ),
                "timeout": int(spec.get("timeout") or 30),
            },
        )

        # -------------------------------------------------------------------
        # Discover VM inventory from GCP Compute Engine
        # -------------------------------------------------------------------
        instances: list[Dict[str, Any]] = []
        page_token = None
        if zone:
            zone_name = str(zone).strip().rstrip("/").split("/")[-1]
            while True:
                params: Dict[str, Any] = {}
                if page_token:
                    params["pageToken"] = page_token
                payload = compute_client.request(
                    "GET",
                    "projects/{}/zones/{}/instances".format(project_id, zone_name),
                    params=params,
                )
                for instance in payload.get("items", []):
                    if isinstance(instance, dict):
                        instances.append(instance)
                page_token = payload.get("nextPageToken")
                if not page_token:
                    break
        else:
            while True:
                params = {}
                if page_token:
                    params["pageToken"] = page_token
                payload = compute_client.request(
                    "GET",
                    "projects/{}/aggregated/instances".format(project_id),
                    params=params,
                )
                for zone_payload in payload.get("items", {}).values():
                    if not isinstance(zone_payload, dict):
                        continue
                    for instance in zone_payload.get("instances", []):
                        if isinstance(instance, dict):
                            instances.append(instance)
                page_token = payload.get("nextPageToken")
                if not page_token:
                    break

        # -------------------------------------------------------------------
        # Discover firewall inventory for exposure checks
        # -------------------------------------------------------------------
        firewalls: list[Dict[str, Any]] = []
        page_token = None
        while True:
            params = {}
            if page_token:
                params["pageToken"] = page_token
            payload = compute_client.request(
                "GET",
                "projects/{}/global/firewalls".format(project_id),
                params=params,
            )
            for firewall in payload.get("items", []):
                if isinstance(firewall, dict):
                    firewalls.append(firewall)
            page_token = payload.get("nextPageToken")
            if not page_token:
                break
    except ValueError as exc:
        return {
            "status": "FAILED",
            "action": "VM_ABUSE_SCAN",
            "reason": "InvalidSpec",
            "detail": str(exc),
        }
    except GCPAPIError as exc:
        logger.error("Failed to scan GCP VM instances: %s", str(exc), exc_info=True)
        return {
            "status": "FAILED",
            "action": "VM_ABUSE_SCAN",
            "reason": "ComputeInventoryFailed",
            "detail": str(exc),
            "http_status": exc.status_code,
            "region": region,
        }

    # -------------------------------------------------------------------
    # Normalize raw Compute Engine inventory
    # -------------------------------------------------------------------
    normalized_instances: list[dict[str, Any]] = []
    for instance in instances:
        has_public_ip = False
        network_name = None
        network_interfaces = instance.get("networkInterfaces", [])
        for interface in network_interfaces if isinstance(network_interfaces, list) else []:
            if not network_name:
                network_ref = interface.get("network")
                network_name = (
                    str(network_ref).strip().rstrip("/").split("/")[-1] if network_ref else None
                )
            access_configs = interface.get("accessConfigs", [])
            for config in access_configs if isinstance(access_configs, list) else []:
                if config.get("natIP"):
                    has_public_ip = True
                    break

        service_account_email = None
        service_accounts = instance.get("serviceAccounts", [])
        if isinstance(service_accounts, list) and service_accounts:
            first_sa = service_accounts[0]
            if isinstance(first_sa, dict):
                service_account_email = first_sa.get("email")

        tags = instance.get("tags", {})
        tag_items = tags.get("items", []) if isinstance(tags, dict) else []
        machine_type = instance.get("machineType")
        machine_type = str(machine_type).strip().rstrip("/").split("/")[-1] if machine_type else None
        instance_zone = instance.get("zone")
        instance_zone = str(instance_zone).strip().rstrip("/").split("/")[-1] if instance_zone else None

        normalized_instances.append(
            {
                "name": instance.get("name"),
                "status": str(instance.get("status") or "").upper(),
                "machine_type": machine_type,
                "zone": instance_zone,
                "network": network_name,
                "has_public_ip": has_public_ip,
                "service_account_email": service_account_email,
                "network_tags": tag_items if isinstance(tag_items, list) else [],
            }
        )

    # -------------------------------------------------------------------
    # Resolve active instances and evaluate abuse rules
    # -------------------------------------------------------------------
    active_instances = [
        instance
        for instance in normalized_instances
        if str(instance.get("status") or "").upper() in {"RUNNING", "PROVISIONING", "STAGING"}
    ]

    abuse_message: list[str] = []

    if "number_of_instances" in instance_rules:
        max_instances = instance_rules["number_of_instances"]
        if isinstance(max_instances, int) and max_instances >= 0:
            if len(active_instances) > max_instances:
                abuse_message.append(
                    "Created {} VM instances when the limit is {}.".format(
                        len(active_instances),
                        max_instances,
                    )
                )
        else:
            return {
                "status": "FAILED",
                "action": "VM_ABUSE_SCAN",
                "reason": "InvalidRuleValue",
                "detail": "instance.number_of_instances must be a non-negative integer",
                "region": region,
            }

    if "allowed_machine_types" in instance_rules:
        allowed_machine_types = instance_rules["allowed_machine_types"]
        if not (isinstance(allowed_machine_types, list) and allowed_machine_types):
            return {
                "status": "FAILED",
                "action": "VM_ABUSE_SCAN",
                "reason": "InvalidRuleValue",
                "detail": "instance.allowed_machine_types must be a non-empty list",
                "region": region,
            }

        allowed_machine_types_set = set(allowed_machine_types)
        allowed_machine_types_str = ", ".join(sorted(allowed_machine_types_set))
        for instance in active_instances:
            machine_type = instance.get("machine_type")
            instance_name = instance.get("name")
            if machine_type and machine_type not in allowed_machine_types_set:
                abuse_message.append(
                    "VM instance {} has unauthorized machine type {}, allowed values: {}.".format(
                        instance_name,
                        machine_type,
                        allowed_machine_types_str,
                    )
                )

    if "allow_public_ip" in instance_rules and not bool(instance_rules["allow_public_ip"]):
        for instance in active_instances:
            instance_name = instance.get("name")
            if instance.get("has_public_ip"):
                abuse_message.append(
                    "VM instance {} has a public IP attached, which is not allowed.".format(
                        instance_name,
                    )
                )

    if "allowed_service_accounts" in instance_rules:
        allowed_service_accounts = instance_rules["allowed_service_accounts"]
        if not (isinstance(allowed_service_accounts, list) and allowed_service_accounts):
            return {
                "status": "FAILED",
                "action": "VM_ABUSE_SCAN",
                "reason": "InvalidRuleValue",
                "detail": "instance.allowed_service_accounts must be a non-empty list",
                "region": region,
            }

        allowed_service_accounts_set = set(allowed_service_accounts)
        allowed_service_accounts_str = ", ".join(sorted(allowed_service_accounts_set))
        for instance in active_instances:
            instance_name = instance.get("name")
            service_account_email = instance.get("service_account_email")
            if service_account_email and service_account_email not in allowed_service_accounts_set:
                abuse_message.append(
                    "VM instance {} uses unauthorized service account {}, allowed values: {}.".format(
                        instance_name,
                        service_account_email,
                        allowed_service_accounts_str,
                    )
                )

    if "forbidden_open_ports" in instance_rules:
        forbidden_open_ports = instance_rules["forbidden_open_ports"]
        if not isinstance(forbidden_open_ports, list):
            return {
                "status": "FAILED",
                "action": "VM_ABUSE_SCAN",
                "reason": "InvalidRuleValue",
                "detail": "instance.forbidden_open_ports must be a list",
                "region": region,
            }

        forbidden_port_set = {str(port) for port in forbidden_open_ports}
        for instance in active_instances:
            instance_name = instance.get("name")
            violating_ports: list[str] = []
            violating_rules: set[str] = set()

            for forbidden_port in forbidden_port_set:
                for firewall in firewalls:
                    if str(firewall.get("direction") or "INGRESS").upper() != "INGRESS":
                        continue
                    if bool(firewall.get("disabled")):
                        continue

                    target_tags = firewall.get("targetTags", [])
                    target_service_accounts = firewall.get("targetServiceAccounts", [])
                    instance_tags = set(str(tag) for tag in instance.get("network_tags", []))
                    service_account_email = str(instance.get("service_account_email") or "")

                    if target_tags and not instance_tags.intersection(
                        set(str(tag) for tag in target_tags)
                    ):
                        continue

                    if target_service_accounts and service_account_email not in {
                        str(item) for item in target_service_accounts
                    }:
                        continue

                    firewall_matched = False
                    for allowed in firewall.get("allowed", []):
                        if not isinstance(allowed, dict):
                            continue
                        protocol = str(allowed.get("IPProtocol") or "").lower()
                        if protocol not in {"tcp", "all"}:
                            continue

                        ports = allowed.get("ports", [])
                        if not ports:
                            firewall_matched = True
                            break

                        if isinstance(ports, list):
                            for allowed_port in ports:
                                allowed_port_text = str(allowed_port).strip()
                                if allowed_port_text == forbidden_port:
                                    firewall_matched = True
                                    break
                                if "-" in allowed_port_text:
                                    try:
                                        start_text, end_text = allowed_port_text.split("-", 1)
                                        start_port = int(start_text)
                                        end_port = int(end_text)
                                        port_number = int(forbidden_port)
                                    except ValueError:
                                        continue
                                    if start_port <= port_number <= end_port:
                                        firewall_matched = True
                                        break
                            if firewall_matched:
                                break

                    if firewall_matched:
                        violating_ports.append(forbidden_port)
                        violating_rules.add(str(firewall.get("name") or "unnamed-firewall"))

            if violating_ports:
                abuse_message.append(
                    "VM instance {} exposes forbidden ports {} through firewall rules {}.".format(
                        instance_name,
                        ", ".join(sorted(set(violating_ports))),
                        ", ".join(sorted(violating_rules)),
                    )
                )

    # -------------------------------------------------------------------
    # Return abuse scan result
    # -------------------------------------------------------------------
    if abuse_message:
        return {
            "status": "FAILED",
            "action": "VM_ABUSE_SCAN",
            "region": region,
            "data": {
                "abuse_found": True,
                "messages": abuse_message,
                "active_instance_count": len(active_instances),
            },
        }

    return {
        "status": "SUCCESS",
        "action": "VM_ABUSE_SCAN",
        "region": region,
        "data": {
            "abuse_found": False,
            "messages": [],
            "active_instance_count": len(active_instances),
        },
    }
