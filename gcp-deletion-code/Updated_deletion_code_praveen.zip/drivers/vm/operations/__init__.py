"""VM operation entry points."""
