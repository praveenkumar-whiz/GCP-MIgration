"""GCP VM demo driver."""
