"""Storage Transfer Service operations"""
